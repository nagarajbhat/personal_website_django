$(function(){
        $(".element1").typed({
            strings: ["^500 Coder"],
            typeSpeed: 100,
            cursorChar: ""
        });
        $(".element2").typed({
            strings: ["^1500, Poet","^500, Amatuer Poet"],
            typeSpeed: 100,
            cursorChar: "!"
        });
    });